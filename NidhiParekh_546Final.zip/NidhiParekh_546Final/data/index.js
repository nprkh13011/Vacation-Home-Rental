const usersData = require('./users');
// const hostsData = require('./host');

module.exports = {
    users: usersData
    // host: hostsData
};