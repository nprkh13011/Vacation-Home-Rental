# Vacation-Home-Rental
An application designed to help users book affordable places that also give the local experience
# How to Use Application:
<br>Run 'npm i' or 'npm install' in order to install all the required libraries for this project
<br>Run 'npm run seed' to run the task of seeding the db
<br>Run 'npm start' to start the router
